/*****************************************************************************/
               TM-T20III UIB specification Firmware Updater

               Copyright (C) Seiko Epson Corporation 2023. All rights reserved.
/*****************************************************************************/

Trademarks
  Microsoft(R), Windows(R), and Windows Vista(R) are registered trademarks or
  trademarks of Microsoft Corporation in the United States and/or
  other countries.

Corresponding model                          : TM-T20III(UIB)
Printer Firmware Version                     : 15.03 ESC/POS

Supported OS
 Windows 11
 Windows 10  (32/64bit)


<File explanation>
(1) TM-T20III_U_Firmware_Updater_Ver.15.03.exe: File for Firmware Update

<Update procedure>
1. Turn on a power of the printer.
2. Execute file (1) above.
3. Follow the instruction of Updater.

<The restoration method for update failure>
If failed to update, the printer will be in
"forced updating firmware mode".
(Power LED:On, Paper LED:Off, Error LED:Flashing three times)

Please reconnect the printer to computer with USB cable 
and try firmware update again.

                                                                           End.
